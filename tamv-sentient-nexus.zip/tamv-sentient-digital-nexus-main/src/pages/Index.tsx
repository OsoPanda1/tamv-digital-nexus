import { useState, useEffect, useRef, useCallback } from "react";
import Navigation from "@/components/Navigation";
import CinematicIntro from "@/components/CinematicIntro";
import Hero from "@/components/Hero";
import KorimaCodex from "@/components/KorimaCodex";
import Philosophy from "@/components/Philosophy";
import EcosystemModules from "@/components/EcosystemModules";
import TechnicalArchitecture from "@/components/TechnicalArchitecture";
import TechStack from "@/components/TechStack";
import SecurityInfrastructure from "@/components/SecurityInfrastructure";
import ComplianceCertifications from "@/components/ComplianceCertifications";
import GlobalUseCases from "@/components/GlobalUseCases";
import BlogIntegration from "@/components/BlogIntegration";
import Roadmap from "@/components/Roadmap";
import Footer from "@/components/Footer";

// Interfaces para mejor tipado
interface SectionInfo {
  id: string;
  name: string;
  color: string;
  progress: number;
}

const Index = () => {
  const [showIntro, setShowIntro] = useState(true);
  const [hasSeenIntro, setHasSeenIntro] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [activeSection, setActiveSection] = useState("hero");
  const [scrollProgress, setScrollProgress] = useState(0);
  const [isTransitioning, setIsTransitioning] = useState(false);
  const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 });
  const [heroInitialized, setHeroInitialized] = useState(false);
  const mainContainerRef = useRef<HTMLDivElement>(null);
  const scrollTimeoutRef = useRef<NodeJS.Timeout>();

  // Información de las secciones para navegación mejorada
  const sections: SectionInfo[] = [
    { id: "hero", name: "Inicio", color: "from-crystal-glow to-crystal-lowgreen", progress: 0 },
    { id: "korima", name: "Kórima", color: "from-purple-400 to-indigo-500", progress: 10 },
    { id: "philosophy", name: "Filosofía", color: "from-pink-400 to-rose-500", progress: 20 },
    { id: "modules", name: "Módulos", color: "from-green-400 to-emerald-500", progress: 30 },
    { id: "arquitectura-tecnica", name: "Arquitectura", color: "from-yellow-400 to-amber-500", progress: 40 },
    { id: "tech", name: "Tecnología", color: "from-blue-400 to-cyan-500", progress: 50 },
    { id: "seguridad", name: "Seguridad", color: "from-indigo-400 to-purple-500", progress: 60 },
    { id: "cumplimiento", name: "Cumplimiento", color: "from-red-400 to-orange-500", progress: 70 },
    { id: "casos-uso", name: "Casos de Uso", color: "from-teal-400 to-green-500", progress: 80 },
    { id: "resources", name: "Recursos", color: "from-violet-400 to-fuchsia-500", progress: 90 },
    { id: "roadmap", name: "Roadmap", color: "from-amber-400 to-yellow-500", progress: 100 }
  ];

  // Efecto para verificar si ya se vio el intro con lógica mejorada
  useEffect(() => {
    const checkIntroStatus = () => {
      try {
        const seen = localStorage.getItem("tamv_intro_seen");
        const introTimestamp = localStorage.getItem("tamv_intro_timestamp");
        const firstVisit = localStorage.getItem("tamv_first_visit");
        
        // Si es la primera visita, forzar el intro
        if (!firstVisit) {
          localStorage.setItem("tamv_first_visit", Date.now().toString());
          setShowIntro(true);
          setHasSeenIntro(false);
          setIsLoading(false);
          return;
        }

        // Si pasaron más de 24 horas, mostrar intro nuevamente
        if (introTimestamp) {
          const now = Date.now();
          const timeDiff = now - parseInt(introTimestamp);
          const hoursDiff = timeDiff / (1000 * 60 * 60);
          
          if (hoursDiff > 24) {
            localStorage.removeItem("tamv_intro_seen");
            localStorage.removeItem("tamv_intro_timestamp");
            setShowIntro(true);
            setHasSeenIntro(false);
          } else if (seen === "true") {
            setShowIntro(false);
            setHasSeenIntro(true);
          }
        } else if (seen === "true") {
          setShowIntro(false);
          setHasSeenIntro(true);
        }
      } catch (error) {
        console.warn("Error accessing localStorage:", error);
        // En caso de error, mostrar intro por defecto
        setShowIntro(true);
      }
      setIsLoading(false);
    };

    // Pequeño delay para una experiencia más fluida
    const timer = setTimeout(checkIntroStatus, 800);
    return () => clearTimeout(timer);
  }, []);

  // Efecto para el progreso del scroll y sección activa
  useEffect(() => {
    const handleScroll = () => {
      if (!mainContainerRef.current) return;

      const scrollTop = window.pageYOffset || document.documentElement.scrollTop;
      const docHeight = document.documentElement.scrollHeight - window.innerHeight;
      const progress = Math.min(100, (scrollTop / docHeight) * 100);
      setScrollProgress(progress);

      // Detectar sección activa con threshold mejorado
      const scrollPosition = scrollTop + window.innerHeight * 0.3;

      for (const section of sections) {
        const element = document.getElementById(section.id);
        if (element) {
          const rect = element.getBoundingClientRect();
          const elementTop = rect.top + scrollTop;
          const elementBottom = elementTop + rect.height;

          if (scrollPosition >= elementTop && scrollPosition < elementBottom) {
            setActiveSection(section.id);
            break;
          }
        }
      }
    };

    // Usar throttle para mejor rendimiento
    const throttledScroll = () => {
      if (scrollTimeoutRef.current) return;
      
      scrollTimeoutRef.current = setTimeout(() => {
        handleScroll();
        scrollTimeoutRef.current = undefined;
      }, 16); // ~60fps
    };

    window.addEventListener("scroll", throttledScroll, { passive: true });
    handleScroll(); // Ejecutar una vez al montar

    return () => {
      window.removeEventListener("scroll", throttledScroll);
      if (scrollTimeoutRef.current) {
        clearTimeout(scrollTimeoutRef.current);
      }
    };
  }, [sections]);

  // Efecto para precarga de recursos críticos
  useEffect(() => {
    if (!showIntro && hasSeenIntro) {
      // Precargar recursos críticos para mejor performance
      const preloadResources = [
        "/fonts/Orbitron-Bold.woff2",
        "/fonts/Exo2-Medium.woff2",
        "/images/cosmic-bg.jpg",
        "/audio/hero-ambient.mp3",
        "/audio/cinematic-intro.mp3"
      ];

      preloadResources.forEach(resource => {
        const link = document.createElement("link");
        link.rel = "preload";
        link.href = resource;
        link.as = resource.includes(".woff2") ? "font" : resource.includes(".mp3") ? "audio" : "image";
        link.crossOrigin = "anonymous";
        document.head.appendChild(link);
      });

      // Precargar componentes críticos
      const preloadComponents = async () => {
        try {
          // Aquí podrías precargar componentes dinámicamente si usas lazy loading
          await Promise.all([
            // Preload de componentes importantes
            import("@/components/Hero"),
            import("@/components/EcosystemModules")
          ]);
        } catch (error) {
          console.warn("Preload de componentes falló:", error);
        }
      };

      preloadComponents();
    }
  }, [showIntro, hasSeenIntro]);

  // Seguimiento del mouse para efectos interactivos
  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      setMousePosition({
        x: (e.clientX / window.innerWidth) * 100,
        y: (e.clientY / window.innerHeight) * 100
      });
    };

    window.addEventListener("mousemove", handleMouseMove, { passive: true });
    return () => window.removeEventListener("mousemove", handleMouseMove);
  }, []);

  // Efectos de partículas en el fondo (solo para secciones no-hero)
  useEffect(() => {
    if (showIntro || isLoading || activeSection === "hero") return;

    const particlesContainer = document.getElementById("particles-container");
    if (!particlesContainer) return;

    const createParticle = () => {
      const particle = document.createElement("div");
      const size = Math.random() * 4 + 1;
      const colors = [
        "rgba(180, 60, 85, 0.7)",  // Crystal Glow
        "rgba(160, 50, 75, 0.7)",  // Crystal Lowgreen
        "rgba(170, 70, 80, 0.7)",  // Crystal Accent
        "rgba(140, 40, 65, 0.7)"   // Crystal Muted
      ];
      
      particle.style.cssText = `
        position: fixed;
        width: ${size}px;
        height: ${size}px;
        background: ${colors[Math.floor(Math.random() * colors.length)]};
        border-radius: 50%;
        pointer-events: none;
        z-index: 0;
        top: ${Math.random() * 100}vh;
        left: ${Math.random() * 100}vw;
        animation: floatParticle ${Math.random() * 20 + 10}s linear infinite;
        filter: blur(${Math.random() * 1.5}px);
      `;
      
      particlesContainer.appendChild(particle);
      
      // Limpieza automática
      setTimeout(() => {
        if (particle.parentNode) {
          particle.remove();
        }
      }, 30000);
    };

    // Crear partículas iniciales
    for (let i = 0; i < 30; i++) {
      setTimeout(createParticle, i * 150);
    }

    // Continuar creando partículas
    const interval = setInterval(createParticle, 800);

    return () => {
      clearInterval(interval);
      // Limpiar partículas existentes
      particlesContainer.innerHTML = '';
    };
  }, [showIntro, isLoading, activeSection]);

  // Efecto para inicializar el Hero después del intro
  useEffect(() => {
    if (!showIntro && hasSeenIntro) {
      const timer = setTimeout(() => {
        setHeroInitialized(true);
      }, 1000);
      return () => clearTimeout(timer);
    }
  }, [showIntro, hasSeenIntro]);

  const handleIntroComplete = useCallback(() => {
    try {
      localStorage.setItem("tamv_intro_seen", "true");
      localStorage.setItem("tamv_intro_timestamp", Date.now().toString());
    } catch (error) {
      console.warn("Error saving to localStorage:", error);
    }
    setShowIntro(false);
    setHasSeenIntro(true);
  }, []);

  const handleSkipIntro = useCallback(() => {
    handleIntroComplete();
  }, [handleIntroComplete]);

  const handleSectionClick = useCallback((sectionId: string) => {
    setIsTransitioning(true);
    const element = document.getElementById(sectionId);
    
    if (element) {
      const offset = 80; // Compensar navbar fija
      const elementPosition = element.offsetTop - offset;
      
      window.scrollTo({
        top: elementPosition,
        behavior: 'smooth'
      });

      // Actualizar sección activa después de la transición
      setTimeout(() => {
        setActiveSection(sectionId);
        setIsTransitioning(false);
      }, 800);
    }
  }, []);

  // Pantalla de carga mejorada
  if (isLoading) {
    return (
      <div className="cosmic-loading-screen">
        <div className="cosmic-loader">
          <div className="loader-orb"></div>
          <div className="loader-ring"></div>
          <div className="loader-glow"></div>
          <div className="loader-particles">
            {[...Array(8)].map((_, i) => (
              <div key={i} className="loader-particle" style={{ animationDelay: `${i * 0.3}s` }}></div>
            ))}
          </div>
        </div>
        <div className="loading-text">
          <div className="loading-title">INICIALIZANDO TAMV MD-X4™</div>
          <div className="loading-subtitle">Preparando experiencia de civilización digital...</div>
        </div>
        <style>{`
          .cosmic-loading-screen {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: linear-gradient(135deg, #0F0B1F 0%, #1A1540 50%, #1E3A5F 100%);
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            z-index: 9999;
          }
          
          .cosmic-loader {
            position: relative;
            width: 140px;
            height: 140px;
            margin-bottom: 2rem;
          }
          
          .loader-orb {
            width: 80px;
            height: 80px;
            background: radial-gradient(circle, rgba(180, 60, 85, 0.8) 0%, rgba(160, 50, 75, 0.6) 50%, transparent 70%);
            border-radius: 50%;
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            animation: pulse 2s ease-in-out infinite alternate;
          }
          
          .loader-ring {
            width: 100%;
            height: 100%;
            border: 3px solid transparent;
            border-top: 3px solid rgba(180, 60, 85, 0.8);
            border-right: 3px solid rgba(160, 50, 75, 0.6);
            border-bottom: 3px solid rgba(170, 70, 80, 0.7);
            border-radius: 50%;
            animation: spin 1.5s linear infinite;
            position: absolute;
            top: 0;
            left: 0;
          }
          
          .loader-glow {
            width: 160px;
            height: 160px;
            border: 2px solid transparent;
            border-top: 2px solid rgba(180, 60, 85, 0.4);
            border-radius: 50%;
            position: absolute;
            top: -10px;
            left: -10px;
            animation: spin 3s linear infinite reverse;
            filter: blur(1px);
            opacity: 0.6;
          }
          
          .loader-particles {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            width: 120px;
            height: 120px;
          }
          
          .loader-particle {
            position: absolute;
            width: 6px;
            height: 6px;
            background: rgba(180, 60, 85, 0.8);
            border-radius: 50%;
            top: 50%;
            left: 50%;
            animation: particleOrbit 3s linear infinite;
          }
          
          .loader-particle:nth-child(1) { transform: translate(-50%, -50%) rotate(0deg) translate(60px) rotate(0deg); }
          .loader-particle:nth-child(2) { transform: translate(-50%, -50%) rotate(45deg) translate(60px) rotate(-45deg); }
          .loader-particle:nth-child(3) { transform: translate(-50%, -50%) rotate(90deg) translate(60px) rotate(-90deg); }
          .loader-particle:nth-child(4) { transform: translate(-50%, -50%) rotate(135deg) translate(60px) rotate(-135deg); }
          .loader-particle:nth-child(5) { transform: translate(-50%, -50%) rotate(180deg) translate(60px) rotate(-180deg); }
          .loader-particle:nth-child(6) { transform: translate(-50%, -50%) rotate(225deg) translate(60px) rotate(-225deg); }
          .loader-particle:nth-child(7) { transform: translate(-50%, -50%) rotate(270deg) translate(60px) rotate(-270deg); }
          .loader-particle:nth-child(8) { transform: translate(-50%, -50%) rotate(315deg) translate(60px) rotate(-315deg); }
          
          .loading-text {
            text-align: center;
            font-family: 'Orbitron', monospace;
          }
          
          .loading-title {
            color: rgba(180, 60, 85, 1);
            font-size: 1.2rem;
            margin-bottom: 0.5rem;
            text-shadow: 0 0 10px rgba(180, 60, 85, 0.5);
          }
          
          .loading-subtitle {
            color: rgba(255, 255, 255, 0.7);
            font-size: 0.9rem;
            animation: text-flicker 3s infinite alternate;
          }
          
          @keyframes pulse {
            0% { transform: translate(-50%, -50%) scale(0.8); opacity: 0.7; }
            100% { transform: translate(-50%, -50%) scale(1.2); opacity: 1; }
          }
          
          @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
          }
          
          @keyframes particleOrbit {
            0% { transform: translate(-50%, -50%) rotate(0deg) translate(60px) rotate(0deg); opacity: 1; }
            50% { opacity: 0.7; }
            100% { transform: translate(-50%, -50%) rotate(360deg) translate(60px) rotate(-360deg); opacity: 1; }
          }
          
          @keyframes text-flicker {
            0%, 19%, 21%, 23%, 25%, 54%, 56%, 100% {
              opacity: 0.7;
            }
            20%, 24%, 55% {
              opacity: 0.4;
            }
          }
        `}</style>
      </div>
    );
  }

  if (showIntro && !hasSeenIntro) {
    return <CinematicIntro onComplete={handleIntroComplete} onSkip={handleSkipIntro} />;
  }

  return (
    <div className="cosmic-experience" ref={mainContainerRef}>
      {/* Efecto de gradiente interactivo basado en mouse (solo para secciones no-hero) */}
      {activeSection !== "hero" && (
        <div 
          className="mouse-gradient"
          style={{
            background: `radial-gradient(circle at ${mousePosition.x}% ${mousePosition.y}%, rgba(180, 60, 85, 0.1) 0%, transparent 50%)`
          }}
        />
      )}

      {/* Barra de progreso del scroll mejorada */}
      <div className="scroll-progress-container">
        <div 
          className="scroll-progress-bar"
          style={{ width: `${scrollProgress}%` }}
        >
          <div className="progress-glow"></div>
        </div>
      </div>

      {/* Navegación por secciones mejorada */}
      <div className="section-navigation">
        {sections.map((section) => (
          <button
            key={section.id}
            className={`nav-dot ${activeSection === section.id ? 'active' : ''} ${
              isTransitioning ? 'transitioning' : ''
            }`}
            onClick={() => handleSectionClick(section.id)}
            aria-label={`Ir a ${section.name}`}
          >
            <div className="dot-core"></div>
            <div className="dot-glow"></div>
            <span className="dot-label">{section.name}</span>
            <div className="progress-line" style={{ width: `${section.progress}%` }}></div>
          </button>
        ))}
      </div>

      {/* Contenedor de partículas (solo para secciones no-hero) */}
      {activeSection !== "hero" && (
        <div id="particles-container" className="particles-container"></div>
      )}

      {/* Navegación principal */}
      <Navigation />
      
      {/* Secciones de contenido */}
      <div id="hero">
        <Hero />
      </div>
      
      <div id="korima">
        <KorimaCodex />
      </div>
      
      <div id="philosophy">
        <Philosophy />
      </div>
      
      <div id="modules">
        <EcosystemModules />
      </div>
      
      <div id="arquitectura-tecnica">
        <TechnicalArchitecture />
      </div>
      
      <div id="tech">
        <TechStack />
      </div>
      
      <div id="seguridad">
        <SecurityInfrastructure />
      </div>
      
      <div id="cumplimiento">
        <ComplianceCertifications />
      </div>
      
      <div id="casos-uso">
        <GlobalUseCases />
      </div>
      
      <div id="resources">
        <BlogIntegration />
      </div>
      
      <div id="roadmap">
        <Roadmap />
      </div>
      
      <Footer />

      <style>{`
        .cosmic-experience {
          min-height: 100vh;
          position: relative;
          background: linear-gradient(135deg, #0F0B1F 0%, #1A1540 50%, #1E3A5F 100%);
          overflow-x: hidden;
        }
        
        .mouse-gradient {
          position: fixed;
          top: 0;
          left: 0;
          width: 100%;
          height: 100%;
          pointer-events: none;
          z-index: 1;
          opacity: 0.5;
          transition: background 0.1s ease;
        }
        
        .scroll-progress-container {
          position: fixed;
          top: 0;
          left: 0;
          width: 100%;
          height: 3px;
          background: rgba(255, 255, 255, 0.1);
          z-index: 1000;
        }
        
        .scroll-progress-bar {
          height: 100%;
          background: linear-gradient(90deg, rgba(180, 60, 85, 0.8), rgba(160, 50, 75, 0.7), rgba(170, 70, 80, 0.6));
          transition: width 0.1s ease;
          position: relative;
        }
        
        .progress-glow {
          position: absolute;
          top: 0;
          right: 0;
          width: 20px;
          height: 100%;
          background: inherit;
          filter: blur(5px);
          opacity: 0.8;
        }
        
        .section-navigation {
          position: fixed;
          right: 1.5rem;
          top: 50%;
          transform: translateY(-50%);
          display: flex;
          flex-direction: column;
          gap: 0.8rem;
          z-index: 90;
        }
        
        .nav-dot {
          position: relative;
          width: 16px;
          height: 16px;
          border: none;
          background: transparent;
          cursor: pointer;
          transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
          display: flex;
          align-items: center;
          justify-content: center;
        }
        
        .dot-core {
          width: 6px;
          height: 6px;
          border-radius: 50%;
          background: rgba(255, 255, 255, 0.3);
          transition: all 0.3s ease;
        }
        
        .dot-glow {
          position: absolute;
          top: 50%;
          left: 50%;
          transform: translate(-50%, -50%);
          width: 0;
          height: 0;
          border-radius: 50%;
          background: rgba(180, 60, 85, 0.3);
          transition: all 0.3s ease;
        }
        
        .nav-dot:hover .dot-core {
          background: rgba(180, 60, 85, 0.8);
          transform: scale(1.3);
        }
        
        .nav-dot:hover .dot-glow {
          width: 20px;
          height: 20px;
        }
        
        .nav-dot.active .dot-core {
          background: rgba(180, 60, 85, 1);
          transform: scale(1.5);
          box-shadow: 0 0 10px rgba(180, 60, 85, 0.8);
        }
        
        .nav-dot.active .dot-glow {
          width: 24px;
          height: 24px;
          background: rgba(180, 60, 85, 0.2);
          animation: pulseGlow 2s infinite;
        }
        
        .nav-dot.transitioning {
          pointer-events: none;
          opacity: 0.7;
        }
        
        .dot-label {
          position: absolute;
          right: 25px;
          top: 50%;
          transform: translateY(-50%);
          background: rgba(15, 11, 31, 0.9);
          color: white;
          padding: 0.4rem 1rem;
          border-radius: 6px;
          font-size: 0.8rem;
          white-space: nowrap;
          opacity: 0;
          transition: all 0.3s ease;
          pointer-events: none;
          backdrop-filter: blur(10px);
          border: 1px solid rgba(255, 255, 255, 0.1);
          font-family: 'Exo 2', sans-serif;
        }
        
        .nav-dot:hover .dot-label {
          opacity: 1;
          transform: translateY(-50%) translateX(-5px);
        }
        
        .progress-line {
          position: absolute;
          bottom: -8px;
          left: 0;
          height: 2px;
          background: linear-gradient(90deg, rgba(180, 60, 85, 0.8), transparent);
          transition: width 0.3s ease;
          border-radius: 1px;
        }
        
        .particles-container {
          position: fixed;
          top: 0;
          left: 0;
          width: 100%;
          height: 100%;
          pointer-events: none;
          z-index: 0;
        }
        
        @keyframes floatParticle {
          0% {
            transform: translateY(0) translateX(0);
            opacity: 0;
          }
          10% {
            opacity: 0.7;
          }
          90% {
            opacity: 0.7;
          }
          100% {
            transform: translateY(-100vh) translateX(100px);
            opacity: 0;
          }
        }
        
        @keyframes pulseGlow {
          0%, 100% {
            opacity: 0.2;
            transform: translate(-50%, -50%) scale(1);
          }
          50% {
            opacity: 0.4;
            transform: translate(-50%, -50%) scale(1.1);
          }
        }
        
        @media (max-width: 768px) {
          .section-navigation {
            right: 0.8rem;
          }
          
          .dot-label {
            display: none;
          }
          
          .nav-dot {
            width: 14px;
            height: 14px;
          }
          
          .dot-core {
            width: 5px;
            height: 5px;
          }
        }
        
        @media (max-width: 480px) {
          .section-navigation {
            display: none;
          }
        }
      `}</style>
    </div>
  );
};

export default Index;
